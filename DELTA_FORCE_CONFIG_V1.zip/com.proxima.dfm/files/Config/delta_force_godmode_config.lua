config = {
  version = "1.0.1",
  game_version = "DeltaForceMobile_1.2.3",
  last_updated = "2025-05-24",
  game_settings = {
    god_mode = {
      enabled = true,
      invincibility = true,
      damage_immunity = 100,
      health_regen_rate = 50.0,
      max_health = 200,
      armor_regen_rate = 20.0,
      description = "Grants full invincibility and rapid health and armor regeneration (HP/armor per second)."
    },
    aimbot = {
      enabled = true,
      sensitivity = {
        assault_rifle = 1.0,
        sniper = 0.95,
        smg = 1.1
      },
      fov = 180,
      target_priority = "closest",
      smoothness = 0.9,
      dynamic_sensitivity = true,
      sticky_target = true,
      weapon_types = { "AR", "Sniper", "SMG", "Shotgun" },
      description = "Strong auto-aim with sticky targeting, weapon-specific sensitivity, and 180-degree FOV."
    },
    aimlock = {
      enabled = true,
      lock_duration = 5.0,
      smoothness = {
        assault_rifle = 0.95,
        sniper = 0.85,
        smg = 0.95
      },
      lock_on_head = true,
      headshot_priority = 0.95,
      fov = 180,
      range = 100.0,
      sticky_aim = true,
      ads_mode = true,
      non_ads_mode = true,
      description = "Powerful sticky aimlock on enemy, works with/without ADS, prioritizes headshots."
    },
    aim_assist = {
      enabled = true,
      strength = 0.95,
      auto_aim_range = 90.0,
      snap_speed = 0.3,
      assist_fov = 120,
      description = "Strong aim assist with quick snap and extended range."
    },
    high_damage = {
      enabled = true,
      damage_multiplier = {
        assault_rifle = 2.5,
        sniper = 3.0,
        smg = 2.0
      },
      critical_hit_chance = 0.7,
      critical_hit_multiplier = 3.0,
      description = "Increases damage output with weapon-specific multipliers."
    },
    no_recoil = {
      enabled = true,
      recoil_reduction = 1.0,
      stabilization_time = 0.0,
      recoil_pattern = "none",
      description = "Completely eliminates recoil for all weapons."
    },
    magic_bullet = {
      enabled = true,
      range = 150.0,
      penetration = true,
      penetration_depth = 2.0,
      auto_target = true,
      description = "Bullets auto-hit targets with wall penetration."
    },
    bullet_track = {
      enabled = true,
      track_speed = 20.0,
      curve_factor = 0.4,
      max_track_distance = 100.0,
      track_mode = "predictive",
      description = "Tracks bullet trajectory with predictive targeting."
    },
    no_lag = {
      enabled = true,
      frame_rate = 90,
      network_optimization = true,
      latency_reduction = 0.9,
      server_region = "auto",
      description = "Optimizes performance for high frame rate and reduced network lag."
    },
    unlimited_ammo = {
      enabled = true,
      ammo_count = -1,
      reload_time = 0.0,
      magazine_size_multiplier = {
        assault_rifle = 2.0,
        sniper = 1.5,
        smg = 2.5
      },
      description = "Provides unlimited ammo with no reload."
    },
    speed_hack = {
      enabled = true,
      speed_multiplier = 2.0,
      sprint_duration = "infinite",
      jump_height_multiplier = 1.5,
      crouch_speed = 1.3,
      description = "Increases movement speed, jump height, and crouch speed."
    },
    wallhack = {
      enabled = true,
      visibility_range = 300.0,
      highlight_enemies = true,
      show_items = true,
      environment_fog = false,
      night_mode_support = true,
      description = "See enemies and items through walls, works in fog and night."
    },
    auto_heal = {
      enabled = true,
      heal_rate = 15.0,
      heal_interval = 0.5,
      max_health = 200,
      auto_medkit = true,
      description = "Auto-heals player with medkit support."
    },
    hitbox_modification = {
      enabled = true,
      hitbox_size_multiplier = 3.0,
      headshot_hitbox_increase = 2.0,
      body_hitbox_increase = 3.0,
      limb_hitbox_increase = 2.5,
      damage_on_hitbox = true,
      damage_multiplier = 1.5,
      description = "Increases enemy hitbox sizes significantly, ensures damage on hitbox shots."
    },
    esp = {
      enabled = true,
      enemy_color = "red",
      distance_display = true,
      health_bar = true,
      visibility_range = 250.0,
      name_display = true,
      environment_adaptation = true,
      description = "Shows enemy names, health, and distance, adapts to environment."
    },
    auto_fire = {
      enabled = true,
      fire_rate = 0.1,
      trigger_range = 50.0,
      crosshair_size = 10,
      crosshair_color = "green",
      description = "Auto-fires with custom crosshair settings."
    },
    teleport = {
      enabled = true,
      max_distance = 100.0,
      cooldown = 5.0,
      teleport_mode = "safe",
      description = "Teleport within max distance with safe mode."
    },
    anti_ban = {
      enabled = true,
      obfuscate_scripts = true,
      bypass_detection = true,
      randomize_packet_data = true,
      description = "Attempts to bypass anti-cheat with randomized data."
    },
    android_optimization = {
      enabled = true,
      cpu_usage_limit = 0.7,
      memory_optimization = true,
      background_process_limit = 2,
      battery_saver = true,
      thermal_management = true,
      description = "Optimizes CPU, memory, and battery for Android devices."
    },
    low_ms = {
      enabled = true,
      target_latency = 20,
      network_priority = "high",
      ping_optimization = true,
      server_selection = "closest",
      description = "Reduces network latency to achieve low ping (ms)."
    },
    high_fps = {
      enabled = true,
      target_fps = 90,
      dynamic_fps_adjustment = true,
      fps_lock = true,
      description = "Targets 90 FPS with dynamic adjustment and lock."
    },
    smooth_graphics = {
      enabled = true,
      texture_quality = "medium",
      anti_aliasing = true,
      shadows = false,
      particle_effects = "low",
      description = "Optimizes graphics for smooth visuals."
    },
    no_frame_drop = {
      enabled = true,
      frame_stabilization = true,
      buffer_size = 2,
      render_priority = "high",
      description = "Prevents frame drops with high render priority."
    }
  }
}